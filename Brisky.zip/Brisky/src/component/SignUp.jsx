// SignupForm.js
import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


const SignUp = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log('Form submitted:', formData);
  };

  return (
    <div className="container mt-5 shadow-lg p-5 rounded">
      <div className="row justify-content-center">
        <div className="col-md-5">
          <form action="https://formspree.io/f/{form_id}" method="post">
            <div className="mb-3">
              <label htmlFor="name" className="form-label">
                
              </label>
              <input 
                type="text"
                className="form-control border-1 rounded-2"
                id="name"
                name="name"
                placeholder='Name'
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                
              </label>
              <input
                type="email"
                className="form-control border-1 rounded-2"
                id="email"
                name="email"
                placeholder='Email'
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
              
              </label>
              <input
                type="password"
                className="form-control border-1 rounded-2"
                id="password"
                name="password"
                placeholder='Password'
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="confirmPassword" className="form-label">
                
              </label>
              <input
                type="password"
                className="form-control border-1 rounded-2"
                id="confirmPassword"
                name="confirmPassword"
                placeholder='ConfirmPassword'
                value={formData.confirmPassword}
                onChange={handleChange}
                required
              />
            </div>
            <button  onSubmit={handleSubmit} type="submit" className="btn btn-primary">
              Sign Up
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
