import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { FaFacebook, FaTwitter, FaInstagram } from 'react-icons/fa';
import { NavLink } from 'react-router-dom';


const Footer = () => {
  return (
    <footer className="footer bg-primary text-light">
      <Container>
        <Row className='h-100 justify-content-center align-items-right'>
          {/* About Us */}
          <Col md={3} sm={6}>
            <h5>About Us</h5>
            <p className='text-center'>
            Welcome to our company, where we pride ourselves on 
            delivering high-quality products and exceptional customer service.
             </p>
          </Col>

          {/* Email Field and Button */}
          <Col md={3} sm={6} className='text-center'>
            <h5>Contact Us</h5>
            <Form action="https://formspree.io/f/{form_id}" method="post">
              <Form.Group controlId="formEmail">
                <Form.Control  className='' 
                  type="email" placeholder="Enter your email" />
              </Form.Group>
              <Button variant="outline-light" type="submit" className='m-2'>
                Subscribe
              </Button>
            </Form>
          </Col>
          {/* Social Icons */}
          <Col md={3} sm={6}>
            <h5>Be in a Touch </h5>
            <div className="social-icons">
              <ul className="m-auto" >
              <li className="d-inline-block"> 
               <NavLink className="text-light" to="https://www.facebook.com"> 
                <FaFacebook className="m-2"/>
              </NavLink>
              </li> 
              <li className="d-inline-block">
              <NavLink className="text-light" to="https://www.twitter.com"> 
              <FaTwitter className="m-2" />
              </NavLink>
              </li> 
              <li className="d-inline-block">
              <NavLink className="text-light" to="https://www.instagram.com"> 
              <FaInstagram  className="m-2"/>
              </NavLink>
              </li> 
              </ul>
            </div>
          </Col>

          {/* Follow Us Button */}
          <Col md={3} sm={6}>
            <h5>Follow Us</h5>
            <Button variant="outline-light">Follow</Button>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
