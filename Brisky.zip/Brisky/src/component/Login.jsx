import React, { useState } from 'react';
//import 'bootstrap/dist/css/bootstrap.min.css';



const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Implement your login logic here
    console.log('Username:', username);
    console.log('Password:', password);
  };

  return (
    <div className="container-fluid">
      <div className="row justify-content-center align-items-center vh-100">
        <div className="col-md-4 col-sm-6 col-xs-12 p-5 text-light  bg-success shadow-lg">
          <form className='' action="https://formspree.io/f/{form_id}" method="post">
            <h2 className="m-5">Login</h2>
            <div className="mb-3">
              <label htmlFor="username" className="form-label">
                Username
              </label>
              <input
                type="text"
                className="form-control border-1 rounded-2"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className="form-control border-1 rounded-2"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="mb-3">
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleLogin}>
                Login 
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
