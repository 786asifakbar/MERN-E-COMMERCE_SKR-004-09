import React from 'react'
import { AiFillAlert } from "react-icons/ai";
import { BsBagFill } from "react-icons/bs";
import { MdOutlineSecurity } from "react-icons/md"
import { BsCashStack } from "react-icons/bs";



function Services() {
  return (
    <React.Fragment> 
    <div className='container py-5'>
      <h3> Services </h3>
    <div className="row d-flex flex-row py-5">
 <div className="col-4 p-5 bg-body shadow-lg"> 
 <AiFillAlert />
 <span> Supper Fast Home Delevery </span> 
 </div>
 <div className="col-4 p-3 bg-body shadow-lg"> 
 <div className='row'> 
 <div className='col'> 
 <MdOutlineSecurity />
 <span> Non Contant Shipping </span>
 </div>
 <div className="col-12 mt-5 shadow-lg bg-body"> 
 <BsCashStack />
 <span> Money Back Garanty. </span>
 </div>
 </div>
 </div>
 <div className="col-4 p-5 bg-body shadow-lg"> 
 <BsBagFill />
 <span> Use Our Services </span>
 </div>

    </div>
    </div>

    </React.Fragment>
  )

}

export default Services;