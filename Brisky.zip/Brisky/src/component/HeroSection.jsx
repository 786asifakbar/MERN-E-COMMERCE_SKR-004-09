import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { NavLink } from 'react-router-dom';



const HeroSection = () => {
  return (
    <div className="hero-section">
      <div className="container">
        <div className="row align-items-center">
      
          {/* Column for Title, Description, and Button */}
          <div className="col-lg-6 py-5">
            <div className="text-lg-left shadow-lg bg-body p-4">
              <h5 className="display-4">Wellcome To Brisky Solutions </h5>
              <p className="lead">
                Discover a world of style and quality with our curated collection.
                 From fashion-forward apparel to must-have accessories, 
                 our store offers an array of choices for every taste. 
                 Elevate your wardrobe and express your unique personality effortlessly. 
                Shop with us today and redefine your fashion statement!.
              </p>
               <NavLink to="/Cart" className="btn btn-success btn-lg">
                Learn More
              </NavLink>
            </div>  
         </div>
        {/* Column for Image */}
        <div className="col-lg-6 p-5 shadow-lg bg-body rounded">
            <img
              src="https://th.bing.com/th/id/OIP.im1BdNMo6poXgoE-DupffQHaFj?rs=1&pid=ImgDetMain" // Replace with your image URL
              alt="Hero Image"
              className="img-fluid rounded-lg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
