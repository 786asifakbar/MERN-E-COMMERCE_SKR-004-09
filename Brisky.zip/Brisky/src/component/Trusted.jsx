import React from 'react'

function Trusted() {
  return (
    <>
    <div className='container shadow-lg bg-body'>
       <h3> Payment Online </h3>
       <div className='row'> 
         <div className="col-sm-6 col-md-3 bg-body ">
        <a href='https://www.bankalfalah.com/'>
          <img className='w-75' 
            src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCAC0AO8DASIAAhEBAxEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAYHAQQFAwL/xABIEAABBAECAgUGBw0IAwEAAAABAAIDBAUGERIhBxMUMUEiMlFhkuEVQlJicYGRFiMzN3JzdIKhsbK00SQ0NXWztcHwU2ST8f/EABsBAQACAwEBAAAAAAAAAAAAAAABBgIFBwQD/8QAKBEBAQABAwIFAwUAAAAAAAAAAAECAwQRBSEGEhOB0RQyUTFBYaHh/9oADAMBAAIRAxEAPwC20REBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEXlDNFPFFNE8Pjla17HNPItPcvVJ3TZZeKIiIgREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQV9pHOdmkbjLT/ALxM4ms9x/BSH4m/oPh6/pVgBUiCQQRuCOYI5EH0qytL5sZKt2aw8durNHFv3zRDkH/T4O961ey3HM9PL2XTxF0ry36vRna/d8/KSogRbRSxERAREQEREBERAREQEREBERAREQEREBERAREQEREBERBSC96duxQsw267uGWF3E0+BHcWu9R8VroqrLZeY7blhjnjccpzKuHF5KtlKcNqEgcQ4ZWb84pB3sK2rEroK9mdsbpXQwyytjaQHSFjS4MBPLc9yq7T2YfibrOInslhzY7LfAAnYSAekfuVqDhePAtcPqIIVg22vNbH+XKur9Ouw1/LPtvefHsrSPpcxspLY8Fk3uA3IjfE4gd25AC+29LmGbKxlnD5SBjj5TiYS5o9IYSN/tXE6Kmhuo9SsHINpytG3oFpoCs/UGOxWSxOUhyMMT4BUsSF72jihLGF4lY7vBbtuvU073xWWxeapxXsbZbNXkJaSN2vY8d7JGO5hw9H9Vvqouh02y/Uo8vsgZROx34O0Eyc2+G+3f8AUp7qPVmD0xHA7IundNYEhrQV4y+SUM2DjxO2YANxvu7x8UEg+tFVp6X6gewu0/bbXcfwjrTA4t9LWmPhJ/WVgYbNY3PUIcjj3ufBIXMc144ZIpW7cUcjfAj6fX3FB0kULvdIWGqZ2HAsqW5LJvRUbM0pjr14S9waZA6Q8RA7+4cvFaua6UdN42Z9ahFNlJ43Fsjq7mx1gR38MzgSfqaR60E+VYdJOpNXYK1Rgx1qOtRu1XuZJFC02DNG7aRpkk3272kbAd6kulNa4rVIsRRQyVL1dokkrSva/iiJ26yJ7QNwDyPIbbj0qJ9MfD2bTHyuuyOx9XBFugsrFyyzYzEzSvL5ZqFOWR7u9z3wsc5x29JW4tDDf4Rg/wDLaH+gxR9uv9PP1FHp+Fs0znvFcXIB1kHa99jEA3yi0eLhy39Q3QS9ERA+tOa+XvZG1z3uDWMaXvc47BrWjckkqiMHqmerrP4T6678C5LIW6Te1SzSMEE0g4djIdvIJY4+gH18wvlchmpNNyZKLDxZOtLkZHSsbBA50pDoml72vewFgIAPIldb/v2KoYKtep0vvigZwse+awWjuEk+PMzyPpJJ+tBbNmzVpwT2rU8cFeBhkmllcGMY0eLiVFm9I+gXSmL4WI2OwkdVtCM/Q7g/4XB6X7U8eIwtRjy2O1ekfM0fHEMfkg+O27t/qUjZpLQ9nHY+nYxuOeWVK8Ilj4I7JIjA366Ih5J7+9BJKtqtdrwWqszJq07BJDLGd2vYe4he3NaYfisTWq13zVadWCKOCu2aZkTGxxtDWtBkI7gvaCzVtM62tPDPESW9ZBIyRm48OJhIQc/Kaj05hnsiyWTr15nhrmwlznzkOOwPVRgv2Pp2/cuqOYB9IVR9LVSuy/pW81oFifrq0rht5bIZI3M3+jiP/QrcHc36B+5BlFpnKYdsogdkaDZ9w3qnWoBJxHw4C7dbm6CjmncetZXmw9y9FVbOHbcLzDke9W7gJpJ8PiJZDu91WMOPp4d27qotieTRu4kBo8S48gFcWJqupY7HVXedDXjY/wDL23d+1bLp8vmyVHxVlj6Onj+/P9cKN0jNq6HN506Zq1bFosnFhtosDWw9o728b2899vFSTUFjpntYu9Vt4qu2pNE5tl2NbFJMYu9zQGSufsfHZq8OiwH7pNUH/wBWb+bCuP8AqtwoCuujLM6akx3wLShkq5GFps22Tua51x/Jr52PAHdyHDtyG3f3qcXamInNe1kK9STsJfJBNbZGW1y8BrnNdJyG/JVBiI2O6VbPwcAK8eRyUkvVbcAjELxJ3ctuI7Lb1RZm1Hr3H6YuTTRYeCxXgMMb+rEr3Q9oc93hxHzW+ru5nmE01BmNCXcVlKFrK4eQSVLAjYLEL3MlEZ4HRhhJDgdttlF+h6Vxq6lhJ8ls9KUN9Dnse0n69h9i7lvo/wBA0aGRsnHNb1NSxIJbNuzwMc2MkOO7w3l9Cj/Q65nV6mbu3j4seSPjcO0o3+hBx+kClXsa8pVTuxmRGIisOZsHffH9QS3flvsArbxWndPYSIQ47H14RtwvkLA+eUd33yV+7j9qq3XH4xtP/l4L+ZKugoKUwNaPG9Kc9OqOrri5lI2xt80RPrPmDNvQDtt9C6vTH/d9L/ncl/BCtCj+N6x+m3/5Fy3+mP8Au+lvz2S/ghQa2qdZvixuG0zh7EbLMuPx1bJ3BIGsrh8LGmBso5A/+Q+A5d+/DMtH6MxmmYBMTHZys8YE9vbdrGkA9VX37mevvP7BFj0a4+bSNd1LeTOSwQ5NtiQ7CVz4g81Q0cg3Y7D1gHfwGx0batdOwaaysjm3ajXMx7pgWvkij5OrP358bPD1fk8ws5ERBCuknNHFacnrxPIt5d3YIeEniEThvM4bfN8n9cKO6h0f2To8xsTY/wC34cDJ2du8mxzst/V3H/zWjqmbM6m1xFRwkEFp2nIw5kdkt7MZontkmdKHuA24i1hHjwruTO6bLEU8E2PwLop45IZWuMJDmSNLXA/ffWgk2isz8Oacxdt7uKxFH2O3uefXweQXH8obO+tQp344x+bb/ta8OjOzcwudz2lsg0RzPBmZHxBzW2a48oMIOx4mnf8AVC93fjjH5tv+1oON0kaYxmCjxlyrYvzT37VvrjcnEoAAa/yPJB8fSpri+jTS1OfE5KKbJunqy1LsbZJ4jGZYy2UBwEYO2/fzXH6Y/wC46b/Srn+mxWDbvMxeDsZF7C9tLG9pLByLzHCHBv19yCLv6M8DbtXbuWvZTIWLM8sgMk/A2NjnFzWDYF3Lu876govi6U2jekSnhqVmaTG5ONu8cp5uiljeW8fDs0uY5vI7d30rewGP1HrunYzWR1Nkqcb7k1eGni3dVDGyNrT3BwHjtzBPLck78uT8CswXSTpmky7cub9nnM154fNu9koLdx4Dbkg6vS5+E0f+kXP4oFPdQYU5/G/B3b7VFj5oZJZKh2fJG0EOidzHI7/sHI9ygXS5+E0d+kXP4oF19faky2MkwWFxMor3MxI1r7ZaHOgidI2Foj35bkk7nw29e4DSzHRbpmHEZCWi+6y7WqzWIpZphI2R0TC/hkZwgbHbblsuh0XZS5kdOSR2pHyvx12SnE+QlzjB1bJWNJPo3IHqAWpkdATClkrNvVeobUkVS1MWvn2je5kbnbOa4u5HbmvPog/wPM/5sf5eJBE2HuXvvyBKst+itMOdxNrzR/NinkDfsJK3qWncDQeJIKcfWg7iSUukeD6QXrTfQZ297HQJ4m22GHMxtv4/1GNLabmfNDk8hEWRREPqQSDZz3+Ej2nwHgP6KejksjwRbPR0cdHHyxTt/v8AV32r6up7T8RUbei7U0FmxZp6hgrSSySO4q4tRP4XPLti6MgrdZoHXjvvc+trYhdsHiOS688PjtxSD96s9F9ngRrTGj8PpdkzqrpbF2w0NsW7G3WOaDxcDGt5Bu/Mjn6yduXH1hoF+fux5bGXG08m1sbZTIH9XKYvwcgfH5TXDu32PcO7bnPUQVnW6PdR5F8H3V6ltXKkRaex15p3tk2IOzpJdgPXswn1hb2m+j+TT2ctZSLKyCqXzsr04WH75WeTwx2pHnnw8u4d4338FPkQQTP6IvZnU+Nz0d+vDDUdjy6F8UjpHdmlMh2IO3PwU7KIggtbRN+DWkmqXX67q77NqcVxHIJdpoHQhvF5vLf9n2bGuNI3dVx4hla5BW7C+053Xskdx9c1gG3B6OH9qmSINahXdUo4+q5we6rVr13PA2DjFG1hcAefPZQbUvR7Pk81Hm8Nfix1ouZPY4mPP9qY4Fs8fV9xPxvo38VYSINekLzatZt58D7gjaLL6wc2F8gGxcxr+YBXrL13Vy9SWCbgf1RkBLBJseEuDee2/evtEEO0bpCzpyXNXL1uG3fycrHOlia8BrA50jhu/nu5x3P0BTArKIIPl9GX7Wq8fqfG3a1Z8HZnWIpo5CZXxbxvILOWzmeT/wDq9fuQvHXH3Vm5X7NtsKwZJ12wp9l87ze/mpmiCH640nc1XBioa1uCsac08jzOx7uPrGtaOHg9GxUmlpQWaEuPsgPhnqOqTgcuJjo+rdt/wtpEFW09B68wklmtgdTQ18bYkMh6xrxKPAOMfA5vFtsCQ4b7fZ6WujC5JZxV6HUVo5OOV02Rv2mvkmfIC10bq7eLltsRsXn9mys5EEL1jpDI6m+5/qr8ERxpldM+xE4ume/qvKAj5DzTuPWvbWejmapgpPhs9lyNAu7NM4OMbmP4S5j+Hyu8Agju+vlLkQVzBozXGRZFW1LqqWTHN2bLVx7n8dhg+LLKWs7/AB3Dv+VvaR0VkdMWsrK3MF1O05zYaccW7Q1r945ZHSfHA5HZvj3nwnCICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIOV2+z8z2fes9us/M9n3oiDPbrHzPZ96ybtjl5nd8n3oiD57dZ+Z7PvTt1nl5ns+9EQZ7dY5eZ7PvTttjhB8jfi2831b+lEUVMBdsHfzPD4vvWRcsfM9n3oiwxQz2yxsD5HsrHbbHzPZ96Isp+gdtscvM9n3rPbJ/mez70RTQ7ZP8z2fenbJ/meyiKKmMG5YHyPZQXbB+R7KIoSdtsb7eR7PvWDdsbb+R3/ACfeiIHbrHFt5G2+3m+9YN+yCRtH7J/qiJL3Ys
             i9YO3mc9/i+9Z7bY+Z7PvREZRg3rA+R4/F96x26x8z2feiKRnttjn5nf8AJ96x26xv8T2feiKEVg5CyCBtH7J9H0rIvWeXmd3yfeiJB//Z' alt='Here is image'/>
        </a>
         </div>
         
         <div className="col-sm-6 col-md-3 bg-body">
            <a href='https://www.meezanbank.com'> 
             <img className='w-100' 
               src='https://th.bing.com/th/id/OIP.FBsXs0RtJtpQEiXqaHAaMwHaEK?w=296&h=180&c=7&r=0&o=5&pid=1.7' alt='Here is image'/>
            </a>
         </div>

         <div className="col-sm-6 col-md-3 bg-body">
            <a href='https://www.nbp.com.pk'>  
              <img className="" 
               src="https://th.bing.com/th/id/OIP.DPLtOTVrX1FW0DpxSZKBVQHaHa?w=155&h=180&c=7&r=0&o=5&pid=1.7"
              alt='Here is image'/>
         </a>
         </div>
       
         <div className="col-sm-6 col-md-3 bg-body">
         <a href='https://ibanking.albaraka.com.pk/AmbitRetail/login'> 
         <img  className='w-50 mt-5'
            src="https://th.bing.com/th?id=OIP.bMTSiMPq64M2PMyLjUF0EwHaEt&w=313&h=199&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2"
         alt='Here is image'/>
         </a>
         </div>
       </div>  

       <div className='row'> 
         <div className="col-sm-6 col-md-3 bg-body ">
         <a href='https://www.abl.com'> 
         <img className='w-75'
           src='https://th.bing.com/th?id=OIP.gYjtWqh8wVInrYQ7Qw2PwwHaBx&w=350&h=83&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2' alt='Here is image'/> 
         </a>
         </div>

         <div className="col-sm-6 col-md-3 bg-body">
             <a href='https://askaribank.com/'> 
             <img  className='w-75' 
                src='https://th.bing.com/th/id/OIP.euWkboTjJlQ_IXi9ZgMseQAAAA?w=300&h=84&c=7&r=0&o=5&pid=1.7' 
             alt='Here is image'/>
         </a>
         </div>

         <div className="col-sm-6 col-md-3 bg-body">
           <a href='https://www.hbl.com'> 
             <img  className='w-50 px-4 ' 
               src="https://th.bing.com/th?q=HBL+Bank+Logo&w=120&h=120&c=1&rs=1&qlt=90&cb=1&pid=InlineBlock&mkt=en-WW&cc=PK&setlang=en&adlt=moderate&t=1&mw=247" alt='Here is image'/>
             </a>
         </div>
       
       
         <div className="col-sm-6 col-md-3 bg-body">
         <a href='https://www.bok.com.pk'> 
         <img className='w-50 px-1'  
           src="https://th.bing.com/th?id=OIP.QHbZIaSBgY0rcoXwlMQ-4gAAAA&w=335&h=174&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2"
         alt='Here is image'/>
         </a>
         </div>
       </div>
     </div>
    </>
  
  );
};
export default Trusted;