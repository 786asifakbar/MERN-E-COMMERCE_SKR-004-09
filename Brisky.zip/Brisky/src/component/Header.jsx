import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiShoppingCart } from "react-icons/fi";



const Header = () => {
  return (
  <React.Fragment>  
  <nav className="navbar navbar-expand-lg  navbar-body  shadow-lg rounded" >
  <div className="container-fluid bg-primary bg-gray-700">
    <NavLink className="navbar-brand" to="/">
        <img src="./images/Brisky Logo.png" className='row navbar-brand w-25 rounded-circle'  alt="my logo img" />
  </NavLink>

    <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
     data-bs-target="#navbarSupportedContent" aria-controls="#navbarSupportedContent" 
     aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse">
      <ul className="navbar-nav m-auto">
        <li className="nav-item">
          <NavLink className="nav-link active text-light" aria-current="page" to="/">Home </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link text-light" to="/About"> About </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link text-light" to="/Products">Products</NavLink>
        </li>
         
        <li className="nav-item">
          <NavLink className="nav-link text-light" to="/Contact">Contact</NavLink>
        </li>
        <li className="nav-item text-right">
          <NavLink className="nav-link" to="/login"> 
          <button variant="outline-light" className='btn btn-light btn-sm text-success'> Login </button> </NavLink>
        </li>
        <li className="nav-item text-right">
          <NavLink className="nav-link" to="/SignUp"> 
             <button className='btn btn-success btn-sm'>  SignUp </button> </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link text-light" to="/Cart"> 
         <FiShoppingCart className="" />
         <span className='text-white'><sup className="bg-success rounded-circle p-1">50</sup></span>
          </NavLink>
        </li>
      </ul>
    </div>
  </div>
</nav>
</React.Fragment>
  )
};
export default Header;