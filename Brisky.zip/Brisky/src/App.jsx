import React, { useState } from 'react';
import { Routes , Route } from "react-router-dom"; 
import './App.css'
import './index.css'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Header from './component/Header';
import HomePage from "./Pages/HomePage";
import About from "./Pages/About";
import Products from "./Pages/Products";
import Contact from "./Pages/Contact";
import SingleProduct from './Pages/SingleProduct';
import Cart from './Pages/Cart';
import ErrorPage from './Pages/ErrorPage'; 
import Login from './component/Login';
import Footer from './component/Footer';
import ProductList from './Pages/ProductList';
import { Container , Row  } from 'react-bootstrap';
import SignUp from './component/SignUp';


function App() {

  return(
      // it is using for applying same style of all pages and access properties of component   
       <React.Fragment>
        <Header />
         <Container>
         <Row>
       <Routes>
        
            <Route path="/" element={<HomePage />}/>,
            <Route path="/About" element={<About />}/>,
            <Route path="/Products" element={<Products />}/>,
            <Route path="/Contact" element={<Contact/>} />,
            <Route path="/SingleProduct/:id" element={<SingleProduct />}/>,
            <Route path="/Cart" element={ <Cart />} />,
            <Route path="*" element={<ErrorPage />} />,
            <Route path="/Login" element={<Login />}/>,
            <Route path="/ProductList" element={ <ProductList/>}/>,
            <Route path="/SignUp" element={ <SignUp/>}/>,        
            
       </Routes>  
       </Row>   
       </Container>   
       <Footer />
    </ React.Fragment>
 
  )
};
   export default App;
