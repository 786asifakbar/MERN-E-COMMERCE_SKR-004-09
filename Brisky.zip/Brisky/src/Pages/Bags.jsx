import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const bagsData = Array.from({ length: 20 }, (_, index) => ({
  id: index + 1,
  name: `Bag ${index + 1}`,
  price: Math.floor(Math.random() * 100) + 20,
  image: `https://www.bing.com/th?id=OIP.I3dWhQGbSYhAR3pAa5lZQAHaHa&${index + 1}`,
}));

const Bags = () => {
  return (
    <div className="container mt-5 bg-body shadow-lg">
      <h1 className="text-center mb-4">Bags Store</h1>
      <div className="row ">
        {bagsData.map((bag) => (
          <div key={bag.id} className="col-lg-3 col-md-4 col-sm-6 mb-4 bg-body shadow-lg">
            <div className="card">
              <img src={bag.image} alt={bag.name} className="card-img-top" />
              <div className="card-body">
                <h5 className="card-title">{bag.name}</h5>
                <p className="card-text">${bag.price}</p>
                <a href="#" className="btn btn-primary">
                  Add to Cart
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Bags;
