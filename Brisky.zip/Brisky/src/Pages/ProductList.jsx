// src/components/ProductList.js
import React from 'react';
import ProductCard from './ProductCard';


const ProductList = ({ products }) => {
  return (
    <> 
  
    <div className="container text-secondary">
    <h1 className="text-center mt-4 mb-4"> </h1>
      <div className="row shadow-lg bg-body">
        {products.map((product) => (
          <div key={product.id} className="col-lg-3 col-md-4 col-sm-6 mb-4 bg-body shadow-lg">
            <ProductCard product={product} />
          </div>
        ))}
      </div>
    </div>
    </>
  );
};


export default ProductList;








