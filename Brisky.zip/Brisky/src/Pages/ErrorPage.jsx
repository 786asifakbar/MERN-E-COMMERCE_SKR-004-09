import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';

const Error = () => {
  return (
    <footer className="bg-body shadow-lg text-danger  py-5">
      <Container>
        <Row>
          {/* 404 Text */}
          <Col xs={12} className="text-center m-2">
            <h1 className="display-1">404</h1>
            <p className="lead">Oops! Page not found.</p>
          </Col>

          {/* Description about Error */}
          <Col xs={12} className="text-center mt-4">
            <p>
              The page you are looking for might be under construction or does
              not exist.
            </p>
          </Col>

          {/* Button */}
          <Col xs={12} className="text-center mt-4">
            <Button variant="light"  className="bg-success p-2 text-light" href="/">
              Back to Home
            </Button>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Error;