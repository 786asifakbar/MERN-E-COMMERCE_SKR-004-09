import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import HeroSection from '../component/HeroSection';
import Services from '../component/Services';
import Trusted from '../component/Trusted';
import CardRow from './CardRow';


const HomePage = () => {

  return (
  
  <div>
       <HeroSection />
       <CardRow />
       <Services />
       <Trusted />
  </div>
  );
};

export default HomePage;
