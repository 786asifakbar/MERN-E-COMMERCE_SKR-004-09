import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';



const glassesData = Array.from({ length: 20 }, (_, index) => ({
  id: index + 1,
  name: `Glass ${index + 1}`,
  price: Math.floor(Math.random() * 100) + 20,
  image: `https://www.eyeglasses.pk/media/catalog/product/1/3/132297f.jpg?${index + 1}`,
}));

const Glassess = () => {
  return (
    <div className="container mt-5 bg-body shadow-lg">
      <h1 className="text-center mb-4">Glasses Store</h1>
      <div className="row">
        {glassesData.map((glass) => (
          <div key={glass.id} className="col-lg-3 col-md-4 col-sm-6 mb-4 bg-body shadow-lg">
            <div className="card">
              <img src={glass.image} alt={glass.name} className="card-img-top" />
              <div className="card-body">
                <h5 className="card-title">{glass.name}</h5>
                <p className="card-text">${glass.price}</p>
                <a href="#" className="btn btn-primary">
                  Add to Cart
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Glassess;
