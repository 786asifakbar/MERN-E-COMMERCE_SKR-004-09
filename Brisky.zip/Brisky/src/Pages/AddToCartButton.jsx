// src/components/AddToCartButton.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const AddToCartButton = ({ onClick }) => {
  return (
    <button
      type="button"
      className="btn btn-primary"
      onClick={onClick}
    >
      Add to Cart
    </button>
  );
};

export default AddToCartButton;
