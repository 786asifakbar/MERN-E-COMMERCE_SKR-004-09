import React , { useState } from 'react';
import { Container ,Row , Col, Button, Modal } from 'react-bootstrap';
import CardRow from './CardRow'

const About = () => {

  const [show, setShow] = useState(false);
  return (
<>
  
    <Container className=''>
      <Row >
    <CardRow/>
    </Row>
      <Row className="justify-content-center bg-body shadow-lg p-5 ">
        <Col xs={12} md={8}>
          <h1 className="text-center mb-4 bg-body">About Us</h1>
          <p className='bg-body '>
            Welcome to our company, where we pride ourselves on 
             delivering high-quality products and exceptional customer service.
             Our team is dedicated to providing you with the best possible experience, 
             from the moment you visit our website to the moment you receive your order.
          </p>
          <p>
            Our products are designed with the latest technology and trends in mind, 
            ensuring that you receive only the best. We use only the highest quality materials, 
            and our team of skilled craftsmen work tirelessly to ensure that every product meets our 
            strict quality standards.
          </p>
          <p>
            We believe that customer satisfaction is key to our success,
             and we go above and beyond to ensure that you are completely 
             satisfied with your purchase. Our customer service team is available
              to answer any questions you may have, and we offer a wide range of customization 
              options to ensure that your product is exactly what you're looking for.
          </p>
          <Button variant="primary" onClick={() => setShow(true)}>
            Learn More
          </Button>
            <Modal show={show} onHide={() => setShow(false)}>
            <Modal.Header closeButton>
              <Modal.Title>More About Us</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <p>
                Our company was founded in 2010, and since then we have grown to become one of the leading providers of high-quality products in the industry. We have a team of over 100 skilled craftsmen and women, and we are constantly expanding our product line to meet the needs of our customers.
              </p>
              <p>
                We are committed to sustainability and responsible manufacturing practices, and we strive to minimize our environmental impact in everything we do. We use only ethically-sourced materials, and we work closely with our suppliers to ensure that they meet our strict standards for quality and sustainability.
              </p>
              <p>
                Thank you for choosing our company. We look forward to serving you!
              </p>
            </Modal.Body>
          </Modal>
        </Col>
      </Row>
    </Container>
   </>
  );
};
export default About;