// src/components/SingleProduct.js
import React from 'react';

const SingleProduct = ({ id, name, price, imageUrl }) => {
  return (
    <div className="p-4 md:w-1/4 lg:w-1/6">
      <div className="h-full border-2 border-gray-200 border-opacity-60 rounded-lg overflow-hidden">
        <img
          className="lg:h-48 md:h-36 w-full object-cover object-center"
          src={imageUrl}
          alt={name}
        />
        <div className="p-6">
          <h2 className="tracking-widest text-xs title-font font-medium text-gray-500 mb-1">
            {name}
          </h2>
          <h1 className="title-font text-lg font-medium text-gray-900 mb-3">
            {price}$
          </h1>
          <div className="flex items-center justify-between">
            <button className="text-indigo-500 inline-flex items-center">
              View Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SingleProduct;
