import React from 'react'
import SingleProduct from './SingleProduct'
import 'bootstrap/dist/css/bootstrap.min.css';
import { NavLink } from 'react-bootstrap';
import Glassess from './Glassess';
import Products from './Products';
import Bags from './Bags';
import CartDetail from './CartDetail';


const Cart = () => {
  return (
    <>  
     <div className="container">
        <div className="row bg-primary">
          <div className="col-sm-12 col-md-2 bg-body shadow-lg">
            <ul className="navbar-nav m-auto">
              <li className="nav-item p-5 m-1">
                <NavLink className="nav-link" to="/SingleProduct"> SingleProduct </NavLink>
                <NavLink className="nav-link" to="/Glasses"> Glassess </NavLink>
                <NavLink className="nav-link" to="/Products"> Caps </NavLink>
                <NavLink className="nav-link" to="/Bags"> Bags </NavLink>
              </li> 
            </ul>
          </div>
            <div className='col-sm-6 col-md-10 bg-body shadow-lg'> 
              {/* <SingleProduct /> */}
              <Glassess />
              <Products />
              <Bags />
              <CartDetail />
            </div>
          </div>
       </div>
     </>
   );
 };
export default Cart;