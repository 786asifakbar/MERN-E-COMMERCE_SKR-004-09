import React from 'react';
import ContactForm from './ContactForm';

const Contact = () => {
  return (
    <div className='shadow-lg bg-body p-5'>
      <h2 className=''>Contact Us</h2>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3571304.
      2372123622!2d66.4454066!3d29.058356940823455!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.
      1!3m3!1m2!1s0x3935d4e60abe0af7%3A0xcd579d655a1c3ad4!2sSukkur%2C%20Sindh%2C%20Pakistan!
      5e0!3m2!1sen!2s!4v1704484348816!5m2!1sen!2s"
       width="400" 
       height="300" 
       style={{border:0}} 
       allowfullscreen="" 
       loading="lazy" 
       referrerpolicy="no-referrer-when-downgrade">
        </iframe>      
       <ContactForm />
         </div>

  )
};

export default Contact;
