import React from 'react';
import ProductList from './ProductList';



const products = Array.from({ length: 20 } , (_, index) => ({
  id: index + 1,
  name: `Product ${index + 1}`,
  image: `https://www.bing.com/th?id=OIP.n1dpwQNO8fLVR-Vqtqnm4AHaHa&w=176&h=185&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2${index + 1}`,
  description: `A description for Product ${index + 1}.`,
  price: Math.floor(Math.random() * 50) + 10, // Random price between 10 and 59.99
}));



function CartDetail() {
  return (
    <>
<div>
   <h1 className="text-center mt-4 mb-4">Watches</h1>
   <ProductList products={products} />
</div>
 
</>
)

};

export default CartDetail;

