// src/components/CardRow.js
import React from 'react';
import Card from 'react-bootstrap/Card';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddToCartButton from './AddToCartButton';


const CardRow = () => {
  const handleAddToCart = () => {
    // Implement your add to cart logic here
    alert('Product added to cart!');
  };
  
  return (
    <div className="row m-1">
      <div className="col-md-3 col-sm-6">
        <Card className='bg-body shadow-lg'>
          <Card.Img variant="top" src="https://media.endclothing.com/media/f_auto,q_auto:eco/prodmedia/media/catalog/product/2/9/29-06-2021_JB_HB0230-FA0075-839_m1_1.jpg" />
          <Card.Body>
            <Card.Title>Cap</Card.Title>
            <Card.Text>This is a sample card.</Card.Text>
            <AddToCartButton onClick={handleAddToCart} />         
          </Card.Body>
        </Card>
      </div>
      <div className="col-md-3 col-sm-6">
        <Card  className='bg-body text-secondary shadow-lg'>
          <Card.Img variant="top" src="https://ae01.alicdn.com/kf/HTB1Yl.mPVXXXXaLXXXXq6xXFXXXg/WILLPOWER-Design-Wooden-Goggle-Glasses-Women-Bamboo-Sunglasses-Men-Fashion-Sport-Sun-Glasses-Wood-Oculos-de.jpg" />
          <Card.Body>
            <Card.Title>Glassess</Card.Title>
            <Card.Text>This is another card.</Card.Text>
            <AddToCartButton onClick={handleAddToCart} />
          </Card.Body>
        </Card>
      </div>
      <div className="col-md-3 col-sm-6">
        <Card className='bg-body text-secondary shadow-lg'>
          <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.IMbJ0nYtNIBbBMAY0lA1vQHaHa?rs=1&pid=ImgDetMain" />
          <Card.Body>
            <Card.Title>Glasses</Card.Title>
            <Card.Text>Yet another card.</Card.Text>
            <AddToCartButton onClick={handleAddToCart} />
          </Card.Body>
        </Card>
      </div>
      <div className="col-md-3 col-sm-6">
        <Card className='bg-body text-secondary shadow-lg '>
          <Card.Img variant="top" src="https://ih1.redbubble.net/image.823585393.9347/tb,1000x1000,medium-pad,1000x1000,f8f8f8.u1.jpg" />
          <Card.Body>
            <Card.Title>Bags+Glases </Card.Title>
            <Card.Text>One more card.</Card.Text>
            <AddToCartButton onClick={handleAddToCart} />
          </Card.Body>
        </Card>
      </div>
    </div>
  );
};
export default CardRow;
